#ifndef __CONFIG__
#define __CONFIG__

#define NUM_BTNS 4

#define POT_PIN A0
#define RED_PIN 5
#define BTN_1 2
#define BTN_2 11
#define BTN_3 10
#define BTN_4 9 


#endif
